-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 31 Okt 2026 pada 16.41
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `harga`, `stok`, `supplier_id`) VALUES
(1, 'BRG001', 'Laptop Asus ROG', 15000000, 10, 1),
(2, 'BRG002', 'Mouse Logitech', 150000, 50, 1),
(3, 'BRG003', 'Keyboard Mechanical', 750000, 30, 2),
(4, 'BRG004', 'Monitor LG 24\"', 2000000, 15, 2),
(5, 'BRG005', 'Flashdisk 64GB', 100000, 100, 3),
(6, 'BRG006', 'Hardisk External 1TB', 850000, 25, 3),
(7, 'BRG007', 'Printer Canon', 1800000, 8, 4),
(8, 'BRG008', 'Speaker JBL', 1200000, 20, 5),
(9, 'BRG009', 'Headset Sony', 950000, 18, 6),
(10, 'BRG010', 'Webcam Logitech', 650000, 22, 7);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `telp` varchar(12) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `nama`, `jenis_kelamin`, `telp`, `alamat`) VALUES
('PLG001', 'Andi Wijaya', 'L', '081234567890', 'Jl. Merdeka No. 1, Surabaya'),
('PLG002', 'Budi Santoso', 'L', '081234567891', 'Jl. Diponegoro No. 2, Sidoarjo'),
('PLG003', 'Citra Dewi', 'P', '081234567892', 'Jl. Ahmad Yani No. 3, Malang'),
('PLG004', 'Dewi Lestari', 'P', '081234567893', 'Jl. Sudirman No. 4, Gresik'),
('PLG005', 'Eko Prasetyo', 'L', '081234567894', 'Jl. Thamrin No. 5, Jakarta'),
('PLG006', 'Fitri Handayani', 'P', '081234567895', 'Jl. Gatot Subroto No. 6, Bandung'),
('PLG007', 'Gunawan Saputra', 'L', '081234567896', 'Jl. Pemuda No. 7, Semarang'),
('PLG008', 'Hesti Rahayu', 'P', '081234567897', 'Jl. Malioboro No. 8, Yogyakarta'),
('PLG009', 'Irfan Hakim', 'L', '081234567898', 'Jl. Braga No. 9, Bandung'),
('PLG010', 'Joko Susilo', 'L', '081234567899', 'Jl. Tunjungan No. 10, Surabaya');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `waktu_bayar` datetime NOT NULL,
  `total` int(11) NOT NULL,
  `metode` enum('TUNAI','TRANSFER','EDC') NOT NULL,
  `transaksi_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `waktu_bayar`, `total`, `metode`, `transaksi_id`) VALUES
(1, '2024-01-01 10:00:00', 15000000, 'TRANSFER', 1),
(2, '2024-01-02 11:00:00', 150000, 'TUNAI', 2),
(3, '2024-01-03 12:00:00', 750000, 'EDC', 3),
(4, '2024-01-04 13:00:00', 2000000, 'TRANSFER', 4),
(5, '2024-01-05 14:00:00', 100000, 'TUNAI', 5),
(6, '2024-01-06 15:00:00', 850000, 'EDC', 6),
(7, '2024-01-07 16:00:00', 1800000, 'TRANSFER', 7),
(8, '2024-01-08 17:00:00', 1200000, 'TUNAI', 8),
(9, '2024-01-09 18:00:00', 950000, 'EDC', 9),
(10, '2024-01-10 19:00:00', 650000, 'TRANSFER', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `telp` varchar(12) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`id`, `nama`, `telp`, `alamat`) VALUES
(1, 'PT. Maju Bersama', '08123456', 'Surabaya'),
(2, 'PT. Senang Sekali', '081515563', 'Bangkalan'),
(3, 'PT. Segar Segar', '0845454663', 'Surabaya'),
(4, 'CV. Sumber Rejeki', '0811223344', 'Sidoarjo'),
(5, 'PT. Cahaya Abadi', '0822334455', 'Malang'),
(6, 'UD. Berkah Jaya', '0833445566', 'Gresik'),
(7, 'PT. Indah Permai', '0844556677', 'Jakarta'),
(8, 'CV. Tiga Putra', '0855667788', 'Bandung'),
(9, 'PT. Sinar Mas', '0866778899', 'Semarang'),
(10, 'UD. Makmur Sentosa', '0877889900', 'Yogyakarta');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `waktu_transaksi` date NOT NULL,
  `keterangan` text NOT NULL,
  `total` int(11) NOT NULL,
  `pelanggan_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id`, `waktu_transaksi`, `keterangan`, `total`, `pelanggan_id`) VALUES
(1, '2024-01-01', 'Pembelian laptop', 15000000, 'PLG001'),
(2, '2024-01-02', 'Pembelian mouse', 150000, 'PLG002'),
(3, '2024-01-03', 'Pembelian keyboard', 750000, 'PLG003'),
(4, '2024-01-04', 'Pembelian monitor', 2000000, 'PLG004'),
(5, '2024-01-05', 'Pembelian flashdisk', 100000, 'PLG005'),
(6, '2024-01-06', 'Pembelian hardisk', 850000, 'PLG006'),
(7, '2024-01-07', 'Pembelian printer', 1800000, 'PLG007'),
(8, '2024-01-08', 'Pembelian speaker', 1200000, 'PLG008'),
(9, '2024-01-09', 'Pembelian headset', 950000, 'PLG009'),
(10, '2024-01-10', 'Pembelian webcam', 650000, 'PLG010');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `transaksi_id` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`transaksi_id`, `barang_id`, `harga`, `qty`) VALUES
(1, 1, 15000000, 1),
(2, 2, 150000, 1),
(3, 3, 750000, 1),
(4, 4, 2000000, 1),
(5, 5, 100000, 1),
(6, 6, 850000, 1),
(7, 7, 1800000, 1),
(8, 8, 1200000, 1),
(9, 9, 950000, 1),
(10, 10, 650000, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` tinyint(2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(35) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `hp` varchar(20) NOT NULL,
  `level` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `alamat`, `hp`, `level`) VALUES
(1, 'admin', 'admin123', 'Administrator', 'Jl. Pusat No. 1', '081111111111', 1),
(2, 'kasir1', 'kasir123', 'Rina Kasir', 'Jl. Kasir No. 2', '082222222222', 2),
(3, 'kasir2', 'kasir123', 'Doni Kasir', 'Jl. Kasir No. 3', '083333333333', 2),
(4, 'gudang1', 'gudang123', 'Sari Gudang', 'Jl. Gudang No. 4', '084444444444', 3),
(5, 'manager', 'manager123', 'Pak Manager', 'Jl. Manager No. 5', '085555555555', 1),
(6, 'user1', 'user123', 'User Satu', 'Jl. User No. 6', '086666666666', 4),
(7, 'user2', 'user123', 'User Dua', 'Jl. User No. 7', '087777777777', 4),
(8, 'user3', 'user123', 'User Tiga', 'Jl. User No. 8', '088888888888', 4),
(9, 'user4', 'user123', 'User Empat', 'Jl. User No. 9', '089999999999', 4),
(10, 'owner', 'owner123', 'Pemilik Toko', 'Jl. Owner No. 10', '081000000000', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_barang_supplier` (`supplier_id`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pembayaran_transaksi` (`transaksi_id`);

--
-- Indeks untuk tabel `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_transaksi_pelanggan` (`pelanggan_id`);

--
-- Indeks untuk tabel `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`transaksi_id`,`barang_id`),
  ADD KEY `fk_detail_barang` (`barang_id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` tinyint(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `fk_barang_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `fk_pembayaran_transaksi` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `fk_transaksi_pelanggan` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggan` (`id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD CONSTRAINT `fk_detail_barang` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detail_transaksi` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
